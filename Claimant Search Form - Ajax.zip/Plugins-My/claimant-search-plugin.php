<?php
/**
 * Plugin Name:       Claimant Search Form
 * Description:       Provides a shortcode [claimant_search] to display a search form for the 'claimant' custom post type.
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Version:           1.0.0
 * Author:            Freelancer Habib
 * Author URI:        http://freelancer.com/u/csehabiburr183
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       claimant-search
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Enqueue plugin scripts and styles.
 *
 * @return void
 */
function csf_enqueue_assets() {
    // Enqueue the stylesheet
    wp_enqueue_style(
        'claimant-search-style',
        plugin_dir_url( __FILE__ ) . 'assets/css/style.css',
        [],
        '1.2.0' // Version can stay the same as CSS didn't change
    );

    // Enqueue the new JavaScript file
    wp_enqueue_script(
        'claimant-search-script',
        plugin_dir_url( __FILE__ ) . 'assets/js/search.js',
        [ 'jquery' ], // Make sure jQuery is loaded first
        '1.2.0', // Version can stay the same as JS didn't change
        true // Load in the footer
    );

    // Pass data from PHP to our JavaScript file securely
    wp_localize_script(
        'claimant-search-script',
        'csf_ajax_object', // Object name to use in JS
        [
            'ajax_url' => admin_url( 'admin-ajax.php' ), // WordPress AJAX URL
            'nonce'    => wp_create_nonce( 'csf_ajax_nonce' ) // Security nonce
        ]
    );
}
add_action( 'wp_enqueue_scripts', 'csf_enqueue_assets' );

/**
 * The AJAX handler function.
 * This is what runs on the server when the form is submitted.
 */
function csf_ajax_search_handler() {
    // 1. Security Check: Verify the nonce.
    check_ajax_referer( 'csf_ajax_nonce', 'nonce' );

    // 2. Sanitize user input from the AJAX request.
    $first_name = isset( $_POST['first_name'] ) ? sanitize_text_field( $_POST['first_name'] ) : '';
    $last_name  = isset( $_POST['last_name'] ) ? sanitize_text_field( $_POST['last_name'] ) : '';
    $state      = isset( $_POST['state'] ) ? sanitize_text_field( $_POST['state'] ) : '';

    // 3. Validate input.
    if ( empty( $first_name ) || empty( $last_name ) ) {
        wp_send_json_error( [ 'message' => 'Please enter both a First Name and a Last Name to search.' ] );
    }

    // 4. Build the query arguments.
    $meta_query_args = [
        'relation' => 'AND',
        [ 'key' => 'first_name', 'value' => $first_name, 'compare' => 'LIKE' ],
        [ 'key' => 'last_name', 'value' => $last_name, 'compare' => 'LIKE' ],
    ];

    if ( ! empty( $state ) ) {
        $meta_query_args[] = [ 'key' => 'state', 'value' => $state, 'compare' => '=' ];
    }

    $args = [
        'post_type'      => 'claimant',
        'posts_per_page' => 1,
        'meta_query'     => $meta_query_args,
        'post_status'    => 'publish',
    ];

    // 5. Run the query.
    $query = new WP_Query( $args );

    // 6. Send the response back to the browser.
    if ( $query->have_posts() ) {
        wp_send_json_success( [ 'message' => '<strong>Match Found</strong><br>A potential match has been found. Please complete the form below.' ] );
    } else {
        wp_send_json_error( [ 'message' => '<strong>No Match Found</strong><br>We could not find a record matching your details.' ] );
    }

    // This is required to terminate immediately and return a proper response
    wp_die();
}
// Hook our function to WordPress's AJAX system for logged-in and logged-out users.
add_action( 'wp_ajax_csf_ajax_search', 'csf_ajax_search_handler' );
add_action( 'wp_ajax_nopriv_csf_ajax_search', 'csf_ajax_search_handler' );


/**
 * The shortcode function to render the HTML form.
 * It's much simpler now as it only displays the form.
 */
function csf_render_search_form_shortcode( $atts ) {
    ob_start();
    ?>
    <div class="csf-container">
        <form id="claimant-search-form" class="csf-form" method="post">
            <div class="csf-field-group csf-field-group-names">
                <div class="csf-field">
                    <label for="csf_first_name">First Name</label>
                    <input type="text" id="csf_first_name" name="csf_first_name" placeholder="Please enter your first name" required>
                </div>
                <div class="csf-field">
                    <label for="csf_last_name">Last Name</label>
                    <input type="text" id="csf_last_name" name="csf_last_name" placeholder="Please enter your last name" required>
                </div>
            </div>
            <div class="csf-field-group">
                <div class="csf-field">
                    <label for="csf_state">State</label>
                    <select id="csf_state" name="csf_state">
                        <option value="">-- Select a State --</option>
                        <?php
                        if ( function_exists( 'acf_get_field' ) ) {
                            $field = acf_get_field('state');
                            if ( $field && is_array( $field['choices'] ) ) {
                                foreach ( $field['choices'] as $value => $label ) {
                                    echo '<option value="' . esc_attr( $value ) . '">' . esc_html( $label ) . '</option>';
                                }
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="csf-field-group">
                <button type="submit" class="csf-submit-button">Search Match</button>
            </div>
        </form>
        
        <!-- This div is now a placeholder, filled by JavaScript -->
        <div class="csf-message" style="display: none;"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode( 'claimant_search', 'csf_render_search_form_shortcode' );

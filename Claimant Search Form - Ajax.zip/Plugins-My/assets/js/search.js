// Ensure the script runs after the document is fully loaded.
jQuery(document).ready(function($) {

    // Listen for the submission of our specific form.
    $('#claimant-search-form').on('submit', function(e) {
        
        // Prevent the default form submission (which causes a page reload).
        e.preventDefault(); 

        var form = $(this);
        var messageDiv = form.next('.csf-message'); // Find the message div that follows the form
        var submitButton = form.find('.csf-submit-button');
        var originalButtonText = submitButton.html();

        // Prepare the data to be sent to the server.
        var formData = {
            action: 'csf_ajax_search', // The WordPress AJAX action hook we will create
            nonce: csf_ajax_object.nonce, // The security nonce
            first_name: form.find('#csf_first_name').val(),
            last_name: form.find('#csf_last_name').val(),
            state: form.find('#csf_state').val(),
        };

        // AJAX request
        $.ajax({
            url: csf_ajax_object.ajax_url, // The WordPress AJAX URL
            type: 'POST',
            data: formData,
            // Before sending, show a loading state.
            beforeSend: function() {
                // Clear previous messages
                messageDiv.hide().removeClass('success error').empty();
                // Update button to show it's working
                submitButton.html('<span class="csf-loader"></span> Searching...');
                submitButton.prop('disabled', true);
            },
            // On success, handle the response from the server.
            success: function(response) {
                if (response.success) {
                    // The server responded with success=true
                    messageDiv.html(response.data.message).addClass('success');
                } else {
                    // The server responded with success=false
                    messageDiv.html(response.data.message).addClass('error');
                }
                // Show the message div with a fade-in effect.
                messageDiv.fadeIn();
            },
            // On error (e.g., server issue), show a generic error.
            error: function() {
                messageDiv.html('An unexpected error occurred. Please try again.').addClass('error').fadeIn();
            },
            // After the request is complete, restore the button.
            complete: function() {
                submitButton.html(originalButtonText);
                submitButton.prop('disabled', false);
            }
        });
    });
});

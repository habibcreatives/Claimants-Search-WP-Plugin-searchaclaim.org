<?php
/**
 * Plugin Name:       Claimant Search Form
 * Description:       Provides a shortcode [claimant_search] to display a search form for the 'claimant' custom post type.
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Version:           1.0.0
 * Author:            Freelancer Habib
 * Author URI:        http://freelancer.com/u/csehabiburr183
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       claimant-search
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die;
}

/**
 * Enqueue plugin stylesheet.
 *
 * @return void
 */
function csf_enqueue_styles() {
    wp_enqueue_style(
        'claimant-search-style', // handle
        plugin_dir_url( __FILE__ ) . 'assets/css/style.css', // path
        [], // dependencies
        '1.1.0' // version
    );
}
add_action( 'wp_enqueue_scripts', 'csf_enqueue_styles' );


/**
 * The main shortcode function.
 *
 * @param array $atts Shortcode attributes.
 * @return string The HTML for the form and results.
 */
function csf_render_search_form_shortcode( $atts ) {

    // --- Start Form Processing ---

    $message      = '';
    $message_type = '';

    // Check if the form has been submitted and the nonce is valid.
    if ( isset( $_POST['csf_nonce'] ) && wp_verify_nonce( $_POST['csf_nonce'], 'csf_search_action' ) ) {

        // Sanitize user input
        $first_name = isset( $_POST['csf_first_name'] ) ? sanitize_text_field( $_POST['csf_first_name'] ) : '';
        $last_name  = isset( $_POST['csf_last_name'] ) ? sanitize_text_field( $_POST['csf_last_name'] ) : '';
        $state      = isset( $_POST['csf_state'] ) ? sanitize_text_field( $_POST['csf_state'] ) : '';

        // The core requirement is to match first and last name.
        if ( ! empty( $first_name ) && ! empty( $last_name ) ) {

            // Build the meta query arguments for WP_Query
            $meta_query_args = [
                'relation' => 'AND',
                [
                    'key'     => 'first_name',
                    'value'   => $first_name,
                    'compare' => 'LIKE', // Use LIKE for partial matches, or '=' for exact.
                ],
                [
                    'key'     => 'last_name',
                    'value'   => $last_name,
                    'compare' => 'LIKE',
                ],
            ];

            // If a state was also selected, add it to the query.
            if ( ! empty( $state ) ) {
                $meta_query_args[] = [
                    'key'     => 'state',
                    'value'   => $state,
                    'compare' => '=',
                ];
            }

            // The main WP_Query
            $args = [
                'post_type'      => 'claimant',
                'posts_per_page' => 1, // We only need to know if at least one exists.
                'meta_query'     => $meta_query_args,
                'post_status'    => 'publish',
            ];

            $query = new WP_Query( $args );

            if ( $query->have_posts() ) {
                // Match found! Set the success message.
                $message      = '<strong>Match Found</strong><br>A potential match has been found. Please complete the form below.';
                $message_type = 'success';
            } else {
                // No match found. Set the error/info message.
                $message      = '<strong>No Match Found</strong><br>We could not find a record matching your details.';
                $message_type = 'error';
            }
            wp_reset_postdata();

        } else {
            // First name or last name was empty.
            $message      = 'Please enter both a First Name and a Last Name to search.';
            $message_type = 'error';
        }
    }

    // --- Start HTML Output ---

    ob_start(); // Start output buffering
    ?>

    <div class="csf-container">

        <form id="claimant-search-form" class="csf-form" action="" method="post">
            
            <?php wp_nonce_field( 'csf_search_action', 'csf_nonce' ); ?>

            <div class="csf-field-group csf-field-group-names">
                <div class="csf-field">
                    <label for="csf_first_name">First Name</label>
                    <input type="text" id="csf_first_name" name="csf_first_name" placeholder="Enter your first name" value="<?php echo isset($_POST['csf_first_name']) ? esc_attr($_POST['csf_first_name']) : ''; ?>" required>
                </div>
                <div class="csf-field">
                    <label for="csf_last_name">Last Name</label>
                    <input type="text" placeholder="Enter your last name" id="csf_last_name" name="csf_last_name" value="<?php echo isset($_POST['csf_last_name']) ? esc_attr($_POST['csf_last_name']) : ''; ?>" required>
                </div>
            </div>

            <div class="csf-field-group">
                <div class="csf-field">
                    <label for="csf_state">State</label>
                    <select id="csf_state" name="csf_state">
                        <option value="">-- Select a State --</option>
                        <?php
                        // Dynamically get choices from the ACF field definition.
                        // NOTE: This requires the ACF plugin to be active.
                        if ( function_exists( 'acf_get_field' ) ) {
                            $field = acf_get_field('state');
                            if ( $field && is_array( $field['choices'] ) ) {
                                $current_state = isset($_POST['csf_state']) ? $_POST['csf_state'] : '';
                                foreach ( $field['choices'] as $value => $label ) {
                                    echo '<option value="' . esc_attr( $value ) . '" ' . selected( $current_state, $value, false ) . '>' . esc_html( $label ) . '</option>';
                                }
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="csf-field-group">
                <button type="submit" name="csf_submit" class="csf-submit-button">Search Match</button>
            </div>

        </form>

        <?php // MOVED THE MESSAGE BLOCK HERE ?>
        <?php if ( ! empty( $message ) ) : ?>
            <div class="csf-message <?php echo esc_attr( $message_type ); ?>">
                <?php echo wp_kses_post( $message ); ?>
            </div>
        <?php endif; ?>

    </div>

    <?php
    return ob_get_clean(); // Return the buffered content
}
add_shortcode( 'claimant_search', 'csf_render_search_form_shortcode' );